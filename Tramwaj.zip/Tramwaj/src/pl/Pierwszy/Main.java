package pl.Pierwszy;

import java.util.Random;

class Zajezdnia {
    static int Zajezdnia =1;
    static int START=2;
    static int LOT=3;
    static int KONIEC_TRASY =4;
    static int ZDERZENIE =5;
    int ilosc_torow;
    int ilosc_zajetych_torow;
    int ilosc_tramwajow;
    Zajezdnia(int ilosc_torow, int ilosc_tramwajow){
        this.ilosc_torow = ilosc_torow;
        this.ilosc_tramwajow = ilosc_tramwajow;
        this.ilosc_zajetych_torow =0;
    }
    synchronized int start(int numer){
        ilosc_zajetych_torow--;
        System.out.println("Pozwolenie na rozpoczecie trasy tramwajowi: "+numer);
        return START;
    }
    synchronized int laduj(){
        try{
            Thread.currentThread().sleep(1000);//sleep for 1000 ms
        }
        catch(Exception ie){
        }
        if(ilosc_zajetych_torow < ilosc_torow){
            ilosc_zajetych_torow++;
            System.out.println("Pozwolenie zajecia toru: "+ ilosc_zajetych_torow);
            return Zajezdnia;
        }
        else
        {return KONIEC_TRASY;}
    }
    synchronized void zmniejsz(){
        ilosc_tramwajow--;
        System.out.println("ZABILEM");
        if(ilosc_tramwajow == ilosc_torow) System.out.println("ILOSC TRAMWAJOW TAKA SAMA JAK ILOSC WOLNYCH TOROW ______________");
    }
}

class Tramwaj extends Thread {
    //definicja stanˇw samolotu
    static int ZAJEZDNIA =1;
    static int START=2;
    static int TRASA =3;
    static int KONIEC_TRASY =4;
    static int ZDERZENIE =5;
    static int TANKUJ=1000;
    static int REZERWA=500;

    //zmienne pomocnicze
    int numer;
    int paliwo;
    int stan;
    int miejsca_zajete;
    Zajezdnia l;
    Random rand;
    public Tramwaj(int numer, int paliwo, Zajezdnia l, int miejsca_zajete ){
        this.numer=numer;
        this.paliwo=paliwo;
        this.stan= TRASA;
        this.l=l;
        this.miejsca_zajete = miejsca_zajete;
        rand=new Random();
    }

    public void run(){
        while(true){
            if(stan== ZAJEZDNIA){
                if(rand.nextInt(2)==1){
                    stan=START;
                    paliwo=TANKUJ;
                    System.out.println("prosze o pozwolenie na rozpoczecie trasy, tramwaj: "+numer);
                    stan=l.start(numer);
                }
                else{
                    System.out.println("Postoje sobie jeszcze troche");
                }
            }
            else if(stan==START){
                System.out.println("Wyruszyłem, tramwaj: "+numer);
                stan= TRASA;
            }
            else if(stan== TRASA){
                paliwo-=rand.nextInt(500);
                miejsca_zajete = rand.nextInt(65);
                if(paliwo<=REZERWA){
                    stan= KONIEC_TRASY;
                }
                else try{
                    sleep(rand.nextInt(1000));
                }
                catch (Exception e){}
            }
            else if(stan== KONIEC_TRASY){
                System.out.println("Pozwolenie na zjazd do zajezdni: "+numer+" ilosc paliwa: "+paliwo+" ilość miejsc: "+miejsca_zajete);
                stan=l.laduj();
                if(stan== KONIEC_TRASY){
                    paliwo-=rand.nextInt(500);
                    System.out.println("REZERWA "+paliwo);
                    if(paliwo<=0) stan= ZDERZENIE;
                }
            }
            else if(stan== ZDERZENIE){
                System.out.println("ZDERZENIE TRAMWAJU: "+numer);
                l.zmniejsz();
            }
        }
    }}


class Glowna {
    static int ilosc_tramwajow =100000;
    static int ilosc_torow =5;
    static Zajezdnia zajezdnia;
    public Glowna(){
    }
    public static void main(String[] args) {
        zajezdnia =new Zajezdnia(ilosc_torow, ilosc_tramwajow);
        for(int i = 0; i< ilosc_tramwajow; i++)
            new Tramwaj(i,2000, zajezdnia, 50 ).start();
    }
}