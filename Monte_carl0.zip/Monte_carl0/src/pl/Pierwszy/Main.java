package pl.Pierwszy;

import java.util.Random;

class Monte_Carlo extends Thread {
    double xStart, xStop, yStart, yStop;
    int licznik_prob;
    double wynik;
    Random losowe;

    public Monte_Carlo(double xStart, double xStop, double yStop, double yStart, int licznik) {
        this.xStart = xStart;
        this.yStart = yStart;
        this.xStop = xStop;
        this.yStop = yStop;
        this.wynik = 0;
        this.losowe = new Random();
        this.licznik_prob = licznik;

    }

    public void run() {
        int trafienie = 0;

        for (int i = 0; i < this.licznik_prob; i++) {
            double x = Math.random();
            double y = Math.random();

            if ((x * x + y * y) <= 1)
                trafienie++;
        }

        this.wynik = trafienie;
    }

    public double Wynik() {
        return this.wynik;
    }

}

public class Main {

    public static void main(String[] args) {
        Monte_Carlo watek1, watek2, watek3, watek4;
        int ilosc_prob = 1000;
        double a = 10;

        watek1 = new Monte_Carlo(0,0, a/2, a/2, ilosc_prob);
        watek2 = new Monte_Carlo(a/2,0, 1, a/2, ilosc_prob);
        watek3 = new Monte_Carlo(0, a/2, a/2, a, ilosc_prob);
        watek4 = new Monte_Carlo(a/2,a/2, a, a, ilosc_prob);

        watek1.run();
        watek2.run();
        watek3.run();
        watek4.run();

        try {
            watek1.join();
            watek2.join();
            watek3.join();
            watek4.join();
        }catch (Exception e){

        }
        double pole = watek1.Wynik() + watek2.Wynik() + watek3.Wynik() + watek4.Wynik();
        pole = pole / ((double)ilosc_prob * 4) * (a * a);
        System.out.println("Pole kola wynosi = " + pole);
    }
}